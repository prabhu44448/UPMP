package com.EDigital;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

public class MongoDBClass {

	MongoClient mongoClient;
	DB database;
	DBCollection   collection;
	MongoDatabase mongoDatabase;
	MongoCollection<Document>  mongoCollection;

	MongoDBClass(String databaseName,String collectionName){
		mongoClient = new MongoClient( "localhost" , 27017 );
		database = mongoClient.getDB(databaseName);
		collection = database.getCollection(collectionName);
		mongoDatabase = mongoClient.getDatabase(databaseName);
		mongoCollection= mongoDatabase.getCollection(collectionName);
		
	}
	
	boolean insert( String uname,String password,String email,String phone,String flatno) {
		
		BasicDBObject whereQuery = new BasicDBObject();
	    whereQuery.put("customerid", uname);
	   
	  
	    DBCursor cursor = collection.find(whereQuery);
	    while (cursor.hasNext()) {
	        return false;
	    }
	    System.out.println(uname);
	    if(check(uname,password))
	    {System.out.print("if it is tru");
	    	return false;
	    	
	    }
		
		
	    
		 Document document =new Document("Customerid",uname); 
		 document.append("Password",password);
		 document.append("Email",email); 
		 document.append("PhoneNumber",phone);
		 document.append("FlatNumber", flatno);
	
			

	       mongoCollection.insertOne(document);
		
		 
		return true;
		
	}
	
	
	
	
	
	
	
	
	boolean check( String uname,String password) {
		
		BasicDBObject whereQuery = new BasicDBObject();
	    whereQuery.put("HeadQuatersID", uname);
	   
	  
	    DBCursor cursor = collection.find(whereQuery);
	    while (cursor.hasNext()) {
	        return true;
	    }
		
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	void insertIntoPaymentsData(String userName,String customerid, String flatno,
			String rent,String duedate,String paymenttype,String cnumber,String
			rcnumber,String edate,String CVV) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
		   LocalDateTime now = LocalDateTime.now();
		   DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss");  
		   LocalDateTime now1 = LocalDateTime.now(); 
		
		 Document document =new Document("Customerid",customerid);
		String penalty="0";
		 document.append("CustomerName", userName);
		 document.append("FlatNumber", flatno);
		 document.append("MonthlyRent", rent);
		 document.append("duedate", duedate);
		 document.append("PaymentType", paymenttype);
		 document.append("cnumber",cnumber);
		 document.append("rcnumber",rcnumber);
		 document.append("edate",edate);
		 document.append("CVV",CVV);
		 document.append("Date", dtf.format(now));
		 document.append("Time", dtf1.format(now1));
		 
		 
		 
		 SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");

	        try {
				Date d1 = sdformat.parse(dtf.format(now));
				Date d2 = sdformat.parse(duedate);
				int result = d1.compareTo(d2);
				System.out.print("result");
				System.out.print(result);
				if (result>0) {
					penalty="30";
				}
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
			 document.append("Penalty", penalty);


		 mongoCollection.insertOne(document);
		
		
	}
	
	
	void insertIntoCustomerData(String customerid,String cname, String address,String cnumber) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
		   LocalDateTime now = LocalDateTime.now();
		   DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss");  
		   LocalDateTime now1 = LocalDateTime.now(); 
		
		 Document document =new Document("CusomerID",customerid);
		
		 document.append("Name", cname);
		 document.append("Address", address);
		 document.append("Contact Number", cnumber);
		 mongoCollection.insertOne(document);
		
		
	}
	
	
	
	
	
	
	
	
	
	void insertIntoHelper(String pname, String quantity,String datetime) {
		
		
		 Document document =new Document("pname",pname);
		 document.append("quantity", quantity);
		 document.append("datetime", datetime);
		 mongoCollection.insertOne(document);
		
		
	}
	
	
	void insertIntoRequests(String name, String flatno,String kind,String desc, String reqid,String status) {

		
		 Document document =new Document("Customerid",name);
		 document.append("Requestid",reqid);
		 document.append("FlatNumber",flatno);

		 document.append("Kind", kind);
		 document.append("Description", desc);
		 document.append("Status", status);

		 mongoCollection.insertOne(document);
		
		
	}
	
	void insertIntoComplaints(String userName, String cname,String pname,String desc) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
		   LocalDateTime now = LocalDateTime.now();
		   DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss");  
		   LocalDateTime now1 = LocalDateTime.now(); 
		
		 Document document =new Document("Customerid",userName);
		 document.append("CustomerName",cname);
		 document.append("FlatNumber", pname);
		 document.append("Description",desc);
		 document.append("Complaintid","Complaint-"+dtf.format(now)+dtf1.format(now1));
		 document.append("ComplaintStatus","0");
		 mongoCollection.insertOne(document);
		
		
	}
	
	String validateUser(String email,String password) {
		{
		BasicDBObject query = new BasicDBObject();
		query.put("OutletID", email);
		query.put("Password", password);
		query.put("role", "admin");
		
		DBObject result = collection.findOne(query);
		if(result!=null)
			return "admin";
		}
		{
			BasicDBObject query = new BasicDBObject();
			query.put("OutletID", email);
			query.put("Password", password);
			query.put("role", "user");
			
			DBObject result = collection.findOne(query);
			if(result!=null) {
				System.out.println(result);
				return "user";
			}
			}
		
		return "null";
	}
	
	
	
	String validateCustomer(String email,String password) {
		{
			System.out.print("customerrrr");
		BasicDBObject query = new BasicDBObject();
		query.put("Email", email);
		query.put("Password", password);
		
		DBObject result = collection.findOne(query);
		if(result!=null)
		{
			return "customer";}
		
		}
		
		
		return "null";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	String validateAdmin(String email,String password) {
		{System.out.print("admin");
		BasicDBObject query = new BasicDBObject();
		query.put("HeadQuatersID", email);
		query.put("Password", password);
		
		DBObject result = collection.findOne(query);
		if(result!=null)
			return "admin";
		}
		
		return "null";
	}
	
	
	
}
