package com.EDigital;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import com.EDigital.MongoDBClass;

/**
 * Servlet implementation class SignInServlet
 */
@WebServlet("/signin")
public class SignInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		
		
		MongoDBClass mongoInstance = new MongoDBClass("test","headquarters");

		MongoDBClass mongoInstance2 = new MongoDBClass("test","customer");

		MongoDBClass mongoInstance1 = new MongoDBClass("rental","customer");
		if(mongoInstance.validateAdmin(email,password) == "admin") {
			System.out.print("+++++customer1");
			session.setAttribute("role", "admin");
			//session.setAttribute("email", password);
			dispatcher = request.getRequestDispatcher("AddCustomer.jsp");
		}			
		/*
		else if(mongoInstance1.validateUser(email,password) == "user") {
			System.out.print("+++++customer2");
			
			session.setAttribute("role", "user");
			session.setAttribute("email", email);
			dispatcher = request.getRequestDispatcher("SalesPage.jsp");
		}*/
		else if(mongoInstance1.validateCustomer(email,password) == "customer") {
			System.out.print("+++++customer");
			session.setAttribute("role", "customer");
			session.setAttribute("email", email);
			dispatcher = request.getRequestDispatcher("CustomerPage.jsp");
		}
		else {
			request.setAttribute("status", "failed");
			dispatcher = request.getRequestDispatcher("SignInPage.jsp");
		}
		dispatcher.forward(request, response);
		
	}

}
