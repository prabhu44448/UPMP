package com.EDigital;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Servlet implementation class OutletComplaintServlet
 */
@WebServlet("/complaints")
public class CustomerComplaintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		
		String userName = request.getParameter("uid");
        String cname = request.getParameter("cname");
        String pname = request.getParameter("flatno");

        String desc = (String)request.getParameter("desc");
        
        MongoDBClass mongoInstance = new MongoDBClass("rental","complaint");
        mongoInstance.insertIntoComplaints( userName,cname, pname, desc);
		
        
        dispatcher = request.getRequestDispatcher("CustomerComplaints.jsp");
       
		request.setAttribute("status", "success");
		dispatcher.forward(request, response);
		 
	}

}
