package com.EDigital;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import jakarta.servlet.http.HttpSession;

public class MongoDBClass {

	MongoClient mongoClient;
	DB database;
	DBCollection   collection;
	MongoDatabase mongoDatabase;
	MongoCollection<Document>  mongoCollection;

	MongoDBClass(String databaseName,String collectionName){
		MongoClientURI URI=new MongoClientURI("mongodb+srv://prabhu:123@cluster0.qycnevx.mongodb.net/?retryWrites=true&w=majority");
		mongoClient = new MongoClient(URI);
		
		database = mongoClient.getDB(databaseName);
		collection = database.getCollection(collectionName);
		mongoDatabase = mongoClient.getDatabase(databaseName);
		mongoCollection= mongoDatabase.getCollection(collectionName);
		
	}
	
	boolean insert1( String cname,String number,String email,String password) {
		
		BasicDBObject whereQuery = new BasicDBObject();
	    whereQuery.put("email", email);
	   
	  
	    DBCursor cursor = collection.find(whereQuery);
	    while (cursor.hasNext()) {
	        return false;
	    }
	    if(check(email,password))
	    {System.out.print("if it is tru");
	    	return false;
	    	
	    }
		
		
	    
		 Document document =new Document("email",email); 
		 document.append("password",password);
		 document.append("cname",cname); 
		 document.append("number",number);
		       mongoCollection.insertOne(document);
		
		 
		return true;
		
	}
	
	
boolean insert( String uname,String password,String email,String phone,String flatno,String lease) {
		
		BasicDBObject whereQuery = new BasicDBObject();
	    whereQuery.put("customerid", uname);
	   
	  
	    DBCursor cursor = collection.find(whereQuery);
	    while (cursor.hasNext()) {
	        return false;
	    }
	    System.out.println(uname);
	    if(check(uname,password))
	    {System.out.print("if it is tru");
	    	return false;
	    	
	    }
		
		
	    
		 Document document =new Document("Customerid",uname); 
		 document.append("Password",password);
		 document.append("Email",email); 
		 document.append("PhoneNumber",phone);
		 document.append("FlatNumber", flatno);
		 document.append("reset", 0);
	
			

	       mongoCollection.insertOne(document);
		
		 
		return true;
		
	}
	
	
boolean insertlease( String uname,String email,String flatno,String lease) {
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-YYYY");  
	   LocalDateTime now = LocalDateTime.now();
		BasicDBObject whereQuery = new BasicDBObject();
	    whereQuery.put("customerid", uname);
	   
	  
	    DBCursor cursor = collection.find(whereQuery);
	    while (cursor.hasNext()) {
	        return false;
	    }
	    
	
	    
		 Document document =new Document("Customerid",uname); 
		 document.append("Email",email); 
		 document.append("FlatNumber", flatno);
		 document.append("LeaseStartDate", dtf.format(now));
		 String substring = dtf.format(now).substring(0, dtf.format(now).length() - 1); // AB
		 String replaced = substring;
		 if(lease.compareTo("1")>0)
		 {
			 document.append("LeaseEndDate", replaced+"5");

		 }
		 else
		 {
			 document.append("LeaseEndDate", replaced+"4");

		 }
	       mongoCollection.insertOne(document);

		 
		return true;
		
	}




boolean insertapartment( String uname,String email,String flatno,String lease) {
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-YYYY");  
	   LocalDateTime now = LocalDateTime.now();
		BasicDBObject whereQuery = new BasicDBObject();
	    whereQuery.put("customerid", uname);
	   
	  
	    DBCursor cursor = collection.find(whereQuery);
	    while (cursor.hasNext()) {
	        return false;
	    }
	    
	
	    
		 Document document =new Document("Customerid",uname); 
		 document.append("Email",email); 
		 document.append("FlatNumber", flatno);
		
	       mongoCollection.insertOne(document);

		 
		return true;
		
	}
	
	boolean check( String uname,String password) {
		
		BasicDBObject whereQuery = new BasicDBObject();
	    whereQuery.put("HeadQuatersID", uname);
	   
	  
	    DBCursor cursor = collection.find(whereQuery);
	    while (cursor.hasNext()) {
	        return true;
	    }
		
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	void insertIntoPaymentsData(String userName,String bill,String ename,String paymenttype,String cnumber,String
			rcnumber,String edate,String CVV) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
		   LocalDateTime now = LocalDateTime.now();
		   DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss");  
		   LocalDateTime now1 = LocalDateTime.now(); 
		   Document document =new Document("Customerid",userName);
		 document.append("PaymentId","Payment-"+dtf.format(now)+dtf1.format(now1));
		 document.append("PaymentType", paymenttype);
		 document.append("bill",bill);
		 document.append("cnumber",cnumber);
		 document.append("rcnumber",rcnumber);
		 document.append("ename",ename);
		 document.append("edate",edate);
		 document.append("CVV",CVV);		 document.append("PaymentStatus","0");

		 document.append("Date", dtf.format(now));
		 document.append("Time", dtf1.format(now1));
		 
		


		 mongoCollection.insertOne(document);
		
		
	}
	
	
	void insertIntoCustomerData(String customerid,String cname, String address,String cnumber) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
		   LocalDateTime now = LocalDateTime.now();
		   DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss");  
		   LocalDateTime now1 = LocalDateTime.now(); 
		
		 Document document =new Document("CusomerID",customerid);
		
		 document.append("Name", cname);
		 document.append("Address", address);
		 document.append("Contact Number", cnumber);
		 mongoCollection.insertOne(document);
		
		
	}
	
	
	
	
	
	
	
	
	
	void insertIntoHelper(String pname, String quantity,String datetime) {
		
		
		 Document document =new Document("pname",pname);
		 document.append("quantity", quantity);
		 document.append("datetime", datetime);
		 mongoCollection.insertOne(document);
		
		
	}
	
	
	void insertIntoRequests(String reqid,String name,String location,String date,String etype,String kspeaker,String topic,String members,String comment,String time1) {

		
		 Document document =new Document("EventId",reqid);
		 document.append("name",name);
		 document.append("location",location);

		 document.append("date", date);
		 document.append("etype", etype);
		 document.append("kspeaker", kspeaker);

		 document.append("topic", topic);
		 document.append("members", members);
		 document.append("comment",comment);
		 document.append("time",time1);

		 mongoCollection.insertOne(document);
		
		
	}
	void insertIntoComplaints(String email, String feedback,String cevent,String desc) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
		   LocalDateTime now = LocalDateTime.now();
		   DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss");  
		   LocalDateTime now1 = LocalDateTime.now(); 
		
		 Document document =new Document("Customerid",email);
		 document.append("cevent",cevent);
		 document.append("feedback", feedback);
		 document.append("Description",desc);
		 document.append("Complaintid","Complaint-"+dtf.format(now)+dtf1.format(now1));
		 document.append("ComplaintStatus","0");
		 mongoCollection.insertOne(document);
		
		
	}
	
	String validateUser(String email,String password) {
		{
		BasicDBObject query = new BasicDBObject();
		query.put("OutletID", email);
		query.put("Password", password);
		query.put("role", "admin");
		
		DBObject result = collection.findOne(query);
		if(result!=null)
			return "admin";
		}
		{
			BasicDBObject query = new BasicDBObject();
			query.put("OutletID", email);
			query.put("Password", password);
			query.put("role", "user");
			
			DBObject result = collection.findOne(query);
			if(result!=null) {
				System.out.println(result);
				return "user";
			}
			}
		
		return "null";
	}
	
	
	
	String validateCustomer(String email,String password,HttpSession session) {
		{
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
			   LocalDateTime now = LocalDateTime.now();
		BasicDBObject query = new BasicDBObject();
		query.put("email", email);
		query.put("password", password);
		System.out.print("_________");
		System.out.print(password);
		DBObject result = collection.findOne(query);
		if(result==null)
		{
			return "null";
		}
		else {
			return "customer";
		}}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	String validateAdmin(String email,String password) {
		{System.out.print("admin");
		BasicDBObject query = new BasicDBObject();
		query.put("HeadQuatersID", email);
		query.put("Password", password);
		
		DBObject result = collection.findOne(query);
		if(result!=null)
			return "admin";
		}
		
		return "null";
	}
	
	
	
}
