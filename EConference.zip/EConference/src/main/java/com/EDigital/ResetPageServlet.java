package com.EDigital;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import javax.swing.text.Document;

import com.EDigital.MongoDBClass;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

/**
 * Servlet implementation class SignInServlet
 */
@WebServlet("/reset")
public class ResetPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();

		MongoDBClass mongoInstance1 = new MongoDBClass("rental","customer");
		if(password1.equals(password2))
		{
			MongoClient mongoClient = new MongoClient( "localhost" , 27017 ); 
			   MongoDatabase db = mongoClient.getDatabase("rental");
			   MongoCollection<org.bson.Document>  collection= db.getCollection("customer");
			   
			   BasicDBObject query = new BasicDBObject();
			   System.out.print(session.getAttribute("email"));
			   query.put("Email", session.getAttribute("email")); // (1)

			   BasicDBObject newDocument = new BasicDBObject();
			   newDocument.put("reset", "1"); 
			   newDocument.put("Password",password1); 

			   BasicDBObject updateObject = new BasicDBObject();
			   updateObject.put("$set", newDocument);

			   db.getCollection("customer").updateOne(query, updateObject);
				dispatcher = request.getRequestDispatcher("CustomerPage.jsp");
				request.setAttribute("status", "successreset");


		}

		else {			request.setAttribute("status", "failreset");

			dispatcher = request.getRequestDispatcher("ResetPage.jsp");

		}
		dispatcher.forward(request, response);
		
	}

}
