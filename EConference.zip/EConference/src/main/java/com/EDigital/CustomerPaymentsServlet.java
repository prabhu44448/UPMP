package com.EDigital;
import java.util.Date;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Servlet implementation class SalesPageServlet
 */
@WebServlet("/customerpayments")
public class CustomerPaymentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		
		String userName = request.getParameter("uid");
		String bill=request.getParameter("bill");
        String ename = request.getParameter("ename");
        String paymenttype = (String)request.getParameter("paymenttype");

        //String status = (String)request.getParameter("status");

        String cnumber = (String)request.getParameter("cnumber");

        String rcnumber = (String)request.getParameter("rcnumber");

        String edate = (String)request.getParameter("edate");
        String CVV = (String)request.getParameter("CVV");
        if (cnumber.equals(rcnumber)){
        
        MongoDBClass mongoInstance = new MongoDBClass("conference","payments");
        mongoInstance.insertIntoPaymentsData( userName,bill,ename,paymenttype,cnumber,rcnumber,edate,CVV);
		
        
       // System.out.println("test");
		dispatcher = request.getRequestDispatcher("CustomerPayments.jsp");
		request.setAttribute("status", "success");
		dispatcher.forward(request, response);
		
        }
        else {
        	dispatcher = request.getRequestDispatcher("CustomerPayments.jsp");
    		request.setAttribute("status", "wrongc");
    		dispatcher.forward(request, response);
    		
        }
		
		
	}

}
