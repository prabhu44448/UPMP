package com.EDigital;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.io.IOException;

/**
 * Servlet implementation class AddOutletServlet
 */
@WebServlet("/addcustomer")
public class AddCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();

        String uname = request.getParameter("username");
        String password = request.getParameter("password");
		String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String flatno = request.getParameter("flatno");

        String lease = request.getParameter("lease");
        
        MongoDBClass mongoInstance = new MongoDBClass("rental","customer");
        MongoDBClass mongoInstance1 = new MongoDBClass("test","headquarters");

        MongoDBClass mongoInstance2 = new MongoDBClass("rental","leasing");

        MongoDBClass mongoInstance3 = new MongoDBClass("rental","apartment");
        System.out.print(mongoInstance1.check(uname, password));
        //
        if (!mongoInstance1.check(uname, password)&& mongoInstance.insert(uname, password,email,phone, flatno,lease)) {
        	mongoInstance3.insertapartment(uname,email,flatno,lease);
        	dispatcher = request.getRequestDispatcher("AddCustomer.jsp");
        	 System.out.print("+++++++++++++");
    		request.setAttribute("status", "success");
        }
        else {
        	dispatcher = request.getRequestDispatcher("AddCustomer.jsp");
    		request.setAttribute("status", "failed");
        }
		
        
        
        //System.out.println("test");
		
		dispatcher.forward(request, response);

		
	}

}
