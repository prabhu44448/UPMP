package com.EDigital;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Servlet implementation class OutletRequestServlet
 */
@WebServlet("/request")
public class CustomerRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
		   LocalDateTime now = LocalDateTime.now();
		   DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss");  
		   LocalDateTime now1 = LocalDateTime.now();

		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		
		String name = request.getParameter("ename");
        String location = request.getParameter("location");
        String date = request.getParameter("date");
        String time1 = request.getParameter("time").toString();
        String etype = request.getParameter("etype");
        System.out.print(time1);

		String kspeaker = request.getParameter("kspeaker");
        String topic = request.getParameter("topic");
        String members = request.getParameter("members").toString();
        String comment = request.getParameter("comment");
        String reqid="Request-"+dtf.format(now)+dtf1.format(now1);
        String status="0";
 
        MongoDBClass mongoInstance = new MongoDBClass("conference","events");
        
        mongoInstance.insertIntoRequests(reqid,name,location,date,etype,kspeaker,topic,members,comment,time1);

		        
        
		
        
        
		dispatcher = request.getRequestDispatcher("CustomerRequests.jsp");
		request.setAttribute("status", "success");
		dispatcher.forward(request, response);
		
	}

}
