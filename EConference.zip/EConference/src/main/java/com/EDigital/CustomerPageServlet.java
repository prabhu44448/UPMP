package com.EDigital;
import java.util.Date;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Servlet implementation class SalesPageServlet
 */
@WebServlet("/customerdata")
public class CustomerPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		
		String userName = request.getParameter("cname");
        String customerid = request.getParameter("uid");
        String flatno = request.getParameter("flatno");
        String rent = request.getParameter("rent");
        String duedate = "";
       // String stock = request.getParameter("stock");
        String paymenttype = (String)request.getParameter("paymenttype");

        //String status = (String)request.getParameter("status");
        
        

        String cnumber = (String)request.getParameter("cnumber");

        String rcnumber = (String)request.getParameter("rcnumber");

        String edate = (String)request.getParameter("edate");
        String CVV = (String)request.getParameter("CVV");
        if (cnumber.equals(rcnumber)){
        
        MongoDBClass mongoInstance = new MongoDBClass("rental","payments");
       // mongoInstance.insertIntoPaymentsData( userName,customerid, flatno,rent,duedate,paymenttype,cnumber,rcnumber,edate,CVV);
		
        
       // System.out.println("test");
		dispatcher = request.getRequestDispatcher("CustomerPage.jsp");
		request.setAttribute("status", "success");
		dispatcher.forward(request, response);
		
        }
        else {
        	dispatcher = request.getRequestDispatcher("CustomerPage.jsp");
    		request.setAttribute("status", "wrongc");
    		dispatcher.forward(request, response);
    		
        }
		
		
	}

}
